"""
Amorphic class
"""


import os
import datetime
from amorphicutils.common import read_param_store
from amorphicutils.amorphiclogging import Log4j
from amorphicutils.errors import AmorphicTokenExpired
from .models import Dataset, Jobs, Views
from .apiwrapper import ApiWrapper
import amorphicapi

LOGGER = Log4j().get_logger()


# pylint: disable=too-few-public-methods

class CoreApi:
    """
    Core class for amorphic api functions
    """

    def __init__(self, api_client):
        self.core_client = api_client

    def __getattr__(self, name):
        ins = amorphicapi.__getattribute__(name)
        return ins(api_client=self.core_client)


class Amorphic:
    """
    Class to initialize Amorphic API
    """

    def __init__(self, url, environment, role_id, param_store_key=None, secure=True, region_name=None):
        """
        Initialize the Amorphic API to execute rest call to Amorphic
        When running locally, AMORPHIC_API_TOKEN must be set as environment variable.
        When running on Amorphic, parameter should be attached to the job and param_store_key should be supplied.

        :param url: url of api gateway.
        :param environment: environment of the amorphic deployment.
        :param role_id: role_id of the user with permission to perform required tasks.
        :param param_store_key: key of value stored in parameter store. Required while running on Amorphic
        :param secure: True if parameter stored as SecureString else False. Default: True
        :param region_name: Region name to get ssm parameters
        """

        self.url = url
        self.environment = environment
        self.role_id = role_id
        self._api_token = None

        if param_store_key:
            param_value_response = read_param_store(param_store_key, secure, region_name=region_name)

            if param_value_response['exitcode'] == 1:
                LOGGER.error("Failed to get value for parameter {param} with error {err}. Ignore if running locally."
                             .format(param=param_store_key, err=param_value_response['message']))
            else:
                self._api_token = param_value_response['data']

        if not self._api_token:
            try:
                LOGGER.debug("Reading AMORPHIC_API_TOKEN from environment.")
                self._api_token = os.environ['AMORPHIC_API_TOKEN']
            except KeyError as key_err:
                LOGGER.error("AMORPHIC_API_TOKEN is not defined as environment variable. "
                             "Ignore if running on Amorphic. Error: {err}".format(err=key_err))
                raise Exception("Failed to read Amorphic api token.")

        # Create ApiWrapper Class
        self.api_wrapper = ApiWrapper(url=self.url, env=self.environment,
                                      auth_key=self._api_token, role_id=self.role_id)
        self.run_check()
        self.dataset = Dataset(self.api_wrapper)
        self.jobs = Jobs(self.api_wrapper)
        self.views = Views(self.api_wrapper)

        # Core API
        config = amorphicapi.Configuration()

        config.host = '{host}/{env}'.format(
            host=self.url,
            env=self.environment
        )
        config.api_key['Authorization'] = self._api_token
        self.core_client = amorphicapi.ApiClient(configuration=config)

        self.core = CoreApi(self.core_client)

    def run_check(self):
        """
        Check the Amorphic API calls by calling health-check path

        :return:
        """
        curr_t = datetime.datetime.utcnow()
        amz_date = curr_t.strftime('%Y%m%dT%H%M%SZ')
        headers = {
            'X-Amz-Date': amz_date
        }
        response = self.api_wrapper.make_request('health_check', headers=headers)
        if response.status_code != 200:
            if 'Token expired' in response.text:
                raise AmorphicTokenExpired("Amorphic Token is expired, please create new Token from Amorphic.")
            raise Exception("Failed to query Amorphic with error {err}".format(err=response.text))

        return {
            'exitcode': 0,
            'message': 'Successfully checked Amorphic api call.'
        }
