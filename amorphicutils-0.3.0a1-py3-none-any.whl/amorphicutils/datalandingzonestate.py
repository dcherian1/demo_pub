"""
Checks status of Data Landing Zone
"""

import os
from amorphicutils import awshelper


class DataLandingZoneState:
    """
    Class to check state of DataLandingZone
    """

    def __init__(self, lz_bucket_name, dlz_bucket_name):
        """
        Initialize the DataLandingZoneState object
        :param lz_bucket_name: Lz bucket name
        :param dlz_bucket_name: Dlz bucket name
        """

        self.lz_bucket_name = lz_bucket_name
        self.dlz_bucket_name = dlz_bucket_name

    @staticmethod
    def is_epoch_dir_exists(
            bucket_name,
            domain_name,
            dataset_name,
            upload_date,
            path=None,
            region=None):
        """
        Returns true if the dir with upload date exists

        :param bucket_name: name of the bucket
        :param domain_name: domain name
        :param dataset_name: dataset name
        :param upload_date: upload date to check if exists
        :param path: path for which to check dir
        :param region: region of aws
        :return: True or False
        """
        if path:
            _prefix = path
        else:
            _prefix = "{0}/{1}/upload_date={2}".format(
                domain_name, dataset_name, upload_date)
        if not path:
            objs = awshelper.list_bucket_objects(bucket_name, _prefix, region)
        else:
            if _prefix.startswith("s3://"):
                path_list = _prefix.split('/')
                bucket_name = path_list[2]
                _prefix = "/".join(path_list[3:])
                objs = awshelper.list_bucket_objects(bucket_name, _prefix, region)
            else:
                objs = os.listdir(_prefix)
        if objs:
            return True

        return False

    def is_dir_exists(self,
                      paths=None,
                      region=None
                      ):
        """
        Returns true if the dir with upload date exists
        :param paths: list of path for which to check dir
        :param region: region of aws
        :return: True or False
        """

        if not isinstance(paths, list):
            paths = [paths]
        results = [self.is_epoch_dir_exists(None, None, None, None, path, region=region) for path in paths]

        return all(results)

    def is_data_load_complete(
            self,
            domain_name,
            dataset_name,
            upload_date,
            region=None):
        """
        Return True if data load is complete

        :param domain_name: domain name
        :param dataset_name: dataset name
        :param upload_date: upload date to check if exists
        :param region: region of aws
        :return: True or False
        """

        dlz_exists = self.is_epoch_dir_exists(
            self.dlz_bucket_name,
            domain_name,
            dataset_name,
            upload_date,
            region)

        # False means data is copied to dlz successfully
        lz_exists = self.is_epoch_dir_exists(
            self.lz_bucket_name,
            domain_name,
            dataset_name,
            upload_date,
            region)

        return dlz_exists and not lz_exists
