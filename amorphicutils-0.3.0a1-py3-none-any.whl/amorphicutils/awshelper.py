"""
This module provide functions to perform aws related tasks.
"""

import boto3
from botocore.exceptions import ClientError
from amorphicutils.amorphiclogging import Log4j

LOGGER = Log4j().get_logger()


def get_object(bucket_name, object_name):
    """Retrieve StreamingBody object from an Amazon S3 bucket

    :param bucket_name: string
    :param object_name: string
    :return: botocore.response.StreamingBody object. If error, return None.

    >>> s3_data = get_object("dlz_bucket_name", "TestDomian/TestDataset/upload_date=153876456/test_file_1.csv").read()
    """

    # Retrieve the object
    s3_client = boto3.client('s3')
    try:
        response = s3_client.get_object(Bucket=bucket_name, Key=object_name)
    except ClientError as cli_err:
        # AllAccessDisabled error == bucket or object not found
        LOGGER.error("Exception with error %s", cli_err)
        return None
    finally:
        del s3_client
    # Return an open StreamingBody object
    return response['Body']


def list_bucket_objects(bucket_name, prefix, region=None):
    """List the objects in an Amazon S3 bucket

    :param bucket_name: bucket name
    :param prefix: prefix of the object to get
    :param region: region of AWS
    :return: List of bucket objects. If error, return None.

    >>> objs = list_bucket_objects("bucket_name", "TestDomain/TestDataset")
    """

    response_content = []

    LOGGER.info("Listing objects from {bucket_name} with prefix {prefix}.".format(
        bucket_name=bucket_name,
        prefix=prefix
    ))

    # Retrieve the list of bucket objects
    if region:
        s3_client = boto3.client('s3', region_name=region)
    else:
        s3_client = boto3.client('s3')
    try:
        # Get objects using paginator
        paginator = s3_client.get_paginator('list_objects_v2')
        operation_parameters = {'Bucket': bucket_name,
                                'Prefix': prefix}
        page_iterator = paginator.paginate(**operation_parameters)
        for page in page_iterator:
            if 'Contents' in page:
                response_content = response_content + page['Contents']
    except ClientError as cli_err:
        # AllAccessDisabled error == bucket not found
        LOGGER.error("Exception with error %s", cli_err)
        return None
    finally:
        del s3_client

    # Only return the contents if we found some keys
    if response_content:
        return response_content

    LOGGER.info("No object found under prefix %s.", prefix)
    return None


def get_last_modified_object_key(
        bucket_name,
        prefix,
        filter_word=None,
        region=None):
    """
    Return key for last modified object in s3

    :param bucket_name:
    :param prefix:
    :param filter_word: word for which to filter
    :param region:
    :return:

    >>> last_modified_key = get_last_modified_object_key("bucket_name", "TestDomian/TestDataset/")
    """

    try:
        def get_last_modified(obj):
            """ Returns value for key LastModified """
            return int(obj['LastModified'].strftime('%s'))
        response = list_bucket_objects(bucket_name, prefix, region=region)
        if response:
            if filter_word:
                s3_objs = [s3_obj for s3_obj in response
                           if filter_word in s3_obj['Key']]
            else:
                s3_objs = response
            if s3_objs:
                last_modified = [s3_obj['Key'] for s3_obj in sorted(
                    s3_objs, key=get_last_modified)][-1]
            else:
                last_modified = None
        else:
            LOGGER.info("No object found under prefix %s", prefix)
            last_modified = None
    except ClientError as cli_err:
        # AllAccessDisabled error == bucket not found
        LOGGER.error("Exception with error %s", cli_err)
        return None

    # Only return the contents if we found some keys
    if last_modified:
        return last_modified

    return None


def get_object_names(
        bucket_name,
        prefix,
        region=None
):

    response = list_bucket_objects(bucket_name, prefix, region=region)
    if response:
        s3_keys = [s3_obj['Key'] for s3_obj in response]
    else:
        LOGGER.info("No object found under prefix %s", prefix)
        s3_keys = None
    return s3_keys


def put_object(dest_bucket_name, dest_object_name, src_data):
    """Add an object to an Amazon S3 bucket

    The src_data argument must be of type bytes or a string that references
    a file specification.

    :param dest_bucket_name: string
    :param dest_object_name: string
    :param src_data: bytes of data or string reference to file spec
    :return: True if src_data was added to dest_bucket/dest_object, otherwise False

    >>> result = put_object("lz_bucket",
                            "TestDomian/TestDataset/upload_date=153876456/userid/csv/test_file_1.csv",
                            src_data)
    """

    # Construct Body= parameter
    if isinstance(src_data, bytes):
        object_data = src_data
    elif isinstance(src_data, str):
        try:
            object_data = open(src_data, 'rb')
            # possible FileNotFoundError/IOError exception
        except ClientError as cli_err:
            LOGGER.error("Cannot read the data with error : %s", cli_err)
            return False
    else:
        LOGGER.error('Type of %s for the argument \'src_data\' is not supported.', str(type(src_data)))
        return False

    # Put the object
    s3_client = boto3.client('s3')
    try:
        s3_client.put_object(
            Bucket=dest_bucket_name,
            Key=dest_object_name,
            Body=object_data)
    except ClientError as cli_err:
        # AllAccessDisabled error == bucket not found
        # NoSuchKey or InvalidRequest error == (dest bucket/obj == src
        # bucket/obj)
        LOGGER.error("Exception with error %s", cli_err)
        return False
    finally:
        # if isinstance(src_data, str):
        #    object_data.close()
        del s3_client
    return True


def put_file_to_s3(dest_bucket_name, dest_object_name, source_filename):
    """
    Store the file to s3

    :param dest_bucket_name: bucket name to store the data
    :param dest_object_name: prefix of the object to store
    :param source_filename: source file name
    :return:

    >>> result = put_file_to_s3("lz_bucket_name",
                                "TestDomian/TestDataset/upload_date=153876456/userid/csv/test_file_1.csv",
                                "/tmp/test_file.csv")
    """
    try:
        s3_client = boto3.client('s3')
        s3_client.upload_file(source_filename, dest_bucket_name, dest_object_name)
    except ClientError as cli_err:
        LOGGER.error("Exception with error %s", cli_err)


def create_bucket(bucket_name, region=None):
    """
    Creates new s3 bucket

    :param bucket_name:
    :param region:
    :return:
    """
    if region:
        conn = boto3.resource("s3", region_name=region)
    else:
        conn = boto3.resource("s3")

    try:
        conn.create_bucket(Bucket=bucket_name)
        LOGGER.info("Created S3 bucket: %s", bucket_name)
    except ClientError as cli_err:
        LOGGER.error("Exception with error %s", cli_err)


def delete_bucket(bucket_name, region=None):
    """
    Deletes the s3 bucket

    :param bucket_name:
    :param region:
    :return:
    """
    if region:
        s3_res = boto3.resource("s3", region_name=region)
    else:
        s3_res = boto3.resource("s3")

    try:
        bucket = s3_res.Bucket(bucket_name)
        bucket.objects.all().delete()
        bucket.delete()
        LOGGER.info("Deleted S3 bucket: %s", bucket_name)
    except ClientError as cli_err:
        LOGGER.error("Exception with error %s", cli_err)
