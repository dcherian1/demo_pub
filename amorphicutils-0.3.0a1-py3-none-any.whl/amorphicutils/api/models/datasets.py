"""
Class for Dataset
"""

import json
import datetime

from amorphicutils.errors import SchemaDetailsValidationException
from amorphicutils.api.utils import generate_json_reponse, text_to_dict
from amorphicutils.amorphiclogging import Log4j
from amorphicutils.api.models.api_common import ApiCommon


# pylint: disable=too-many-arguments,invalid-name,too-many-branches,too-many-statements,too-many-locals,unused-argument
# pylint: disable=too-many-nested-blocks


class Dataset(ApiCommon):
    """
    Class to call dataset related API
    """

    def __init__(self, api_wrapper):
        ApiCommon.__init__(self, api_wrapper=api_wrapper)
        self.api_wrapper = api_wrapper
        self.log4j = Log4j()
        self._logger = self.log4j.get_logger()
        self.dwh_supported_fileformats = {
            'redshift': ['csv', 'xlsx', 'parquet'],
            'auroramysql': ['csv', 'xlsx'],
            's3athena': ['csv', 'xlsx', 'parquet']
        }
        supported_file_formats = ['csv', 'xlsx', 'parquet', 'txt', 'pdf', 'jpg', 'png', 'mp3', 'wav', 'others']
        connection_type = ['api', 's3', 'jdbc', 'ext-fs']
        object_storage_service = ['s3']
        self.dataset_param_validation_functions = {
            'DatasetName': lambda x: bool(x and isinstance(x, str)),
            'DatasetDescription': lambda x: bool(x and isinstance(x, str)) or bool(not x),
            'Domain': lambda x: bool(x and isinstance(x, str)),
            'Keywords': lambda x: bool(x and isinstance(x, list)) or bool(not x),
            'RecordKeys': lambda x: bool(x and isinstance(x, list)) or bool(not x),
            'ConnectionType': lambda x: x in connection_type,
            'FileType': lambda x: x in supported_file_formats,
            'TargetLocation': lambda x: x in self.dwh_supported_fileformats.keys() or x in object_storage_service,
            'TableUpdate': lambda x: x in ['append', 'reload', 'update'],
            'IsDataProfilingEnabled': lambda x: x in ['true', 'false', True, False],
            'IsDataValidationEnabled': lambda x: x in ['true', 'false', True, False] or bool(not x),
            'TargetTablePrepMode': lambda x: x in ['recreate', 'truncate'],
            'SkipFileHeader': lambda x: x in ['true', 'false', True, False]
        }
        self.supported_datatypes = ['double precision', 'date', 'timestamp', 'bigint']

    @staticmethod
    def _validate_malware_detection(malware_input):
        """
        Validates malware detection option and return the value

        :param malware_input: Input for malware detection to be validated
        :return:
        """

        if malware_input and isinstance(malware_input, dict):
            malware_detection = {}
            for key in ['ScanForMalware', 'AllowUnscannableFiles']:
                value = malware_input.get(key, None)
                if value not in ['true', 'false', True, False]:
                    raise ValueError("MalwareDetectionOptions must contains "
                                     "ScanForMalware and AllowUnscannableFiles keys with value as true or false.")
                malware_detection[key] = value
        else:
            malware_detection = {"ScanForMalware": 'false', "AllowUnscannableFiles": 'false'}

        return malware_detection

    def _get_validated_dataset_payload(self, arguments):
        # Validate the arguments
        for k, validation_func in self.dataset_param_validation_functions.items():
            if not validation_func(arguments[k]):
                raise Exception("Failed to validate value for key: {key} with value: {value}".
                                format(key=k,
                                       value=arguments[k]))

        if not arguments['DatasetDescription']:
            arguments['DatasetDescription'] = 'Created using Amorphicutils'

        # Validate DatasetKeyOptions params
        for key, value in arguments['DatasetKeyOptions'].items():
            if key == 'SortType' and value not in ['none', 'interleaved', 'compound']:
                raise ValueError("SortType must be one from {types}".format(types=['none', 'interleaved', 'compound']))
            if key == 'DistType' and value not in ['auto', 'even', 'key', 'all']:
                raise ValueError("DistType must be one from {types}.".format(types=['auto', 'even', 'key', 'all']))

        # Validate the parameters for data warehouse
        if arguments['TargetLocation'] in self.dwh_supported_fileformats.keys():
            if arguments['FileType'] not in self.dwh_supported_fileformats[arguments['TargetLocation']]:
                raise Exception("File format {format} not supported for target location {target}. "
                                "The supported formats are: {formats}"
                                .format(format=arguments['FileType'],
                                        target=arguments['TargetLocation'],
                                        formats=self.dwh_supported_fileformats[arguments['TargetLocation']]))
            if not arguments['DatasetSchema']:
                raise Exception("dataset_schema cannot be empty for dataset with target location as {target}."
                                .format(target=arguments['TargetLocation'])
                                )

            cleaned_dataset_schema = self.validated_schema(arguments['DatasetSchema'])

        # Check Malware detection

        malware_detection = self._validate_malware_detection(arguments['MalwareDetectionOptions'])

        payload = {
            'DatasetName': arguments['DatasetName'],
            'Domain': arguments['Domain'],
            'ConnectionType': arguments['ConnectionType'],
            'FileType': arguments['FileType'],
            'TargetLocation': arguments['TargetLocation'],
            'TableUpdate': arguments['TableUpdate'],
            'MalwareDetectionOptions': malware_detection,
            'Keywords': arguments['Keywords'] if arguments['Keywords'] else ["CreatedBy:Amorphicutils"],
            'DatasetDescription': arguments['DatasetDescription'],
            'NotificationSettings': arguments['NotificationSettings'],
            'IsDataValidationEnabled': arguments['IsDataValidationEnabled'],
            'TargetTablePrepMode': arguments['TargetTablePrepMode']
        }

        if arguments['DataClassification']:
            payload['DataClassification'] = arguments['DataClassification']
        else:
            payload['DataClassification'] = []

        # Add Arguments for DWH
        schema_payload = None
        if arguments['TargetLocation'] in self.dwh_supported_fileformats.keys():
            payload['IsDataProfilingEnabled'] = arguments['IsDataProfilingEnabled']
            payload['FileDelimiter'] = arguments['FileDelimiter']
            payload['SkipFileHeader'] = arguments['SkipFileHeader']
            schema_payload = {
                'DatasetSchema': cleaned_dataset_schema
            }

            if arguments['PartitionKeys']:
                schema_payload['PartitionKeys'] = arguments['PartitionKeys']

            # Validate input for dataset schema if target type is redshift/aurora/s3-athena
            if arguments['TableUpdate'] == 'update':
                if not arguments['RecordKeys']:
                    raise SchemaDetailsValidationException("RecordKeys need to passed for "
                                                           "table update type update.")
                if set(arguments['RecordKeys']) - {elem['name'] for elem in cleaned_dataset_schema}:
                    raise SchemaDetailsValidationException('RecordKeys must be one of the '
                                                           'columns from the schema.')
                schema_payload['RecordKeys'] = arguments['RecordKeys']
                schema_payload['LatestRecordIndicator'] = arguments['LatestRecordIndicator'] \
                    if arguments['LatestRecordIndicator'] \
                    else {"name": "upload_time", "type": "bigint"}

            # Add arguments for table type redshift
            if arguments['TargetLocation'] == 'redshift':
                field_names = [x['name'] for x in cleaned_dataset_schema]

                # Validate sort keys
                if arguments['DatasetKeyOptions']['SortType'] == 'none':
                    arguments['DatasetKeyOptions']['SortKeys'] = []
                if arguments['DatasetKeyOptions']['SortType'] != 'none' and \
                        not arguments['DatasetKeyOptions']['SortKeys']:
                    raise SchemaDetailsValidationException('SortKeys need to be passed for SortType {type}'
                                                           .format(type=arguments['DatasetKeyOptions']['SortType'])
                                                           )
                if arguments['DatasetKeyOptions']['SortType'] != 'none' and \
                        not all([elem in field_names for elem in arguments['DatasetKeyOptions']['SortKeys']]):
                    raise SchemaDetailsValidationException('SortKeys {keys} should be from the schema fields.'
                                                           .format(keys=arguments['DatasetKeyOptions']['SortKeys'])
                                                           )
                schema_payload['SortType'] = arguments['DatasetKeyOptions']['SortType']
                schema_payload['SortKeys'] = arguments['DatasetKeyOptions']['SortKeys']

                # Validate dist keys
                if arguments['DatasetKeyOptions']['DistType'] == 'key':
                    if not arguments['DatasetKeyOptions']['DistKey']:
                        raise SchemaDetailsValidationException('For DistType as "key", '
                                                               'DistKey is need to passed under DatasetKeyOptions.')
                    if arguments['DatasetKeyOptions']['DistKey'] not in field_names:
                        raise SchemaDetailsValidationException('DistKey {key} should be from the schema fields.'
                                                               .format(key=arguments['DatasetKeyOptions']['DistKey'])
                                                               )
                    schema_payload['DistType'] = arguments['DatasetKeyOptions']['DistType']
                    schema_payload['DistKey'] = arguments['DatasetKeyOptions']['DistKey']
                else:
                    schema_payload['DistType'] = arguments['DatasetKeyOptions']['DistType']
                    schema_payload['DistKey'] = ""

        #if arguments['kwargs']:
        #    self._logger.warning("Following arguments {args} are not defined in function "
        #                         "and thus not used under payload.".format(args=arguments['kwargs']))

        return payload, schema_payload

    def create_domain(self, DomainName, DisplayName=None, DomainDescription=None):
        """
        Creates domain in Amorphic , return success if domain already exists

        :param DomainName: domain name
        :param DisplayName: display name for domain
        :param DomainDescription: description of the domain
        :return:
        """

        self._logger.info("In {name}, creating domain with name {d_name}.".format(
            name=__name__, d_name=DomainName
        ))

        domain_response = self.get_domain(DomainName)
        if not domain_response['exitcode'] == 0:
            # Creates domain
            _path = "domains"
            if DomainName.isalnum() and DomainName[0].isalpha():
                payload = {
                    "DomainName": DomainName.lower(),
                    "DisplayName": DisplayName if DisplayName else DomainName,
                    "DomainDescription": DomainDescription if DomainDescription else "Created via Amorphicutils."
                }
                domain_creation_response = self.api_wrapper.make_request(_path, method='post', headers=None,
                                                                         data=json.dumps(payload), verify=True)

                response = generate_json_reponse(domain_creation_response)
            else:
                response = generate_json_reponse(None,
                                                 exitcode=1,
                                                 message="Domain name should be alphanumeric and starts with alphabet.")
        else:
            response = generate_json_reponse(domain_response['data'],
                                             1,
                                             "Domain {name} already exists with details {details}"
                                             .format(name=DomainName, details=domain_response['message']))
        return response

    def get_domain(self, DomainName):
        """
        Returns domain details

        :param DomainName: domain name
        :return:
        """

        self._logger.info("In {name}, getting domain details with name {d_name}.".format(
            name=__name__, d_name=DomainName
        ))

        # Get domain
        _path = "domains"
        curr_t = datetime.datetime.utcnow()
        amz_date = curr_t.strftime('%Y%m%dT%H%M%SZ')
        headers = {
            'X-Amz-Date': amz_date
        }
        domains_response = self.api_wrapper.make_request(_path, fields=DomainName.lower(), method='get',
                                                         headers=headers, verify=True)
        if domains_response.status_code == 200:
            domains_response_text = text_to_dict(domains_response.text)
            domain_details = domains_response_text['domains']
            response = generate_json_reponse(None, 1, "No domain with name {name} found.".format(name=DomainName))
            for domain in domain_details:
                if domain['DomainName'].lower() == DomainName.lower():
                    response = generate_json_reponse(domain, 0, "Returned domain details.")
                    break
        else:
            response = generate_json_reponse(domains_response)
        return response

    def delete_domain(self, DomainName):
        """
        Deletes domain

        :param DomainName:
        :return:
        """

        self._logger.info("In {name}, deleting domain with name {d_name}.".format(
            name=__name__, d_name=DomainName
        ))

        # Delete domain
        _path = "domain_details"
        curr_t = datetime.datetime.utcnow()
        amz_date = curr_t.strftime('%Y%m%dT%H%M%SZ')
        headers = {
            'X-Amz-Date': amz_date
        }
        domain_deletion_response = self.api_wrapper.make_request(_path, fields=DomainName.lower(),
                                                                 method='delete', headers=headers, verify=True)
        return generate_json_reponse(domain_deletion_response)

    def validated_schema(self, schema):
        """
        Returns the validated schema for Amorphic request

        :param schema: schema of format [{'name': 'id', 'type': 'varchar'}]
        :return:
        """

        failed_validation = []
        final_schema = []
        for elem in schema:
            if "name" not in elem.keys() or "type" not in elem.keys():
                failed_validation.append(elem)
            elif "name" in elem.keys() and "type" in elem.keys() and \
                    not (elem["type"].lower() in self.supported_datatypes
                         or elem["type"].lower().startswith('varchar')):
                failed_validation.append(elem)
            else:
                final_schema.append(
                    {'name': elem['name'],
                     'type': elem['type'].lower()}
                )
        if failed_validation:
            raise Exception("Validation failed for {failed_elem}".format(failed_elem=failed_validation))
        return final_schema

    def create_dataset(self, DatasetName, Domain, ConnectionType, FileType,
                       TargetLocation, TableUpdate, MalwareDetectionOptions=None,
                       Keywords=None, DatasetDescription='Created using Amorphicutils',
                       IsDataProfilingEnabled='false', FileDelimiter=',', IsDataValidationEnabled='false',
                       SkipFileHeader='false', DataClassification=None, TargetTablePrepMode='truncate',
                       NotificationSettings='all', DatasetSchema=None, RecordKeys=None,
                       DatasetKeyOptions=None,
                       LatestRecordIndicator=None, PartitionKeys=None, **kwargs):
        """
        Creates the dataset in Amorphic, returns dataset details if already exists

        :param DatasetName: Dataset name
        :param Domain: Domain under which to create dataset
        :param ConnectionType: Connection type for dataset, must be one of ['api', 's3', 'jdbc', 'ext-fs']
        :param FileType: File type of the input based on target type. Full list is
            ['csv', 'xlsx', 'parquet', 'txt', 'pdf', 'jpg', 'png', 'mp3', 'wav', 'others']
        :param TargetLocation: Target location of dataset, must be from ['redshift', 'auroramysql', 's3athena', 's3']
        :param TableUpdate: Data ingestion type, must be from ['append', 'reload', 'update']
        :param MalwareDetectionOptions: Malware detection in dict format,
            key must be from ['ScanForMalware', 'AllowUnscannableFiles'] and value can be True or False
        :param Keywords: Keywords for the dataset
        :param DatasetDescription: Description of the dataset
        :param IsDataProfilingEnabled: if want to enable data profiling, default: false
        :param FileDelimiter: delimiter for structure data, default: ','
        :param IsDataValidationEnabled: Validate schema for each file for s3athena type dataset. Default: false
        :param SkipFileHeader: true if header exists, default false
        :param DataClassification: Data classification for the dataset
        :param TargetTablePrepMode: Mode for reload type dataset, can be from ['recreate', 'truncate'].
            Default: truncate
        :param NotificationSettings: type of notification setings, default: all
        :param DatasetSchema: schema of the dataset in format of [{'name': 'id', 'type': 'varchar'}]
        :param RecordKeys: record key for table update type update
        :param DatasetKeyOptions: Defines options for SortType, SortKeys, DistType, DistKey
            * SortType: sort type for target type redshift, must be from ['none', 'interleaved', 'compound']
            * SortKeys: sort keys for target type redshift
            * DistType: dist type for target type redshift must be from ['auto', 'even', 'key', 'all']
            * DistKey: dist key type for target type redshift
            * Default: {'SortType': 'none', 'SortKeys':None, 'DistType': 'auto', 'DistKey': ''}
        :param LatestRecordIndicator: latest record key for table update type update,
            default: {"name": "upload_time", "type": "bigint"}
        :param PartitionKeys: List of Dicts of (name, type, rank) to be used as partition
        :param kwargs:
        :return:
        """

        self._logger.info("In {name}, creating dataset with DatasetName {d_name}.".format(
            name=__name__, d_name=DatasetName
        ))

        _path = "register_dataset"

        dataset_response = self.get_dataset(DatasetName)
        if not dataset_response['exitcode'] == 0:

            arguments = locals()
            if not arguments['DatasetKeyOptions']:
                arguments['DatasetKeyOptions'] = {'SortType': 'none', 'SortKeys': None,
                                                  'DistType': 'auto', 'DistKey': ''}

            payload, schema_payload = self._get_validated_dataset_payload(arguments)

            # Remove DataClassification as not available
            if not payload['DataClassification']:
                payload.pop('DataClassification')

            # Add the extra kwargs to payload
            payload.update(**kwargs)

            # Calling Amorphic API
            headers = {'Content-Type': 'text/plain'}

            dataset_creation_response = self.api_wrapper.make_request(_path, method='post',
                                                                      headers=headers, data=json.dumps(payload),
                                                                      verify=True)

            response = generate_json_reponse(dataset_creation_response)

            if TargetLocation in self.dwh_supported_fileformats.keys():
                if response['exitcode'] == 0:
                    dataset_id = response['data']['DatasetId']
                    _path = 'dataset_details'
                    dataset_schema_response = self.api_wrapper.make_request(
                        _path, method='put', fields=dataset_id,
                        headers=headers, data=json.dumps(schema_payload),
                        verify=True)
                    if dataset_schema_response.status_code == 200:
                        response = generate_json_reponse(dataset_creation_response)
                    else:
                        # Delete the dataset to avoid incomplete dataset
                        self.delete_dataset(DatasetName=DatasetName)
                        response = generate_json_reponse(dataset_schema_response)
        else:
            response = generate_json_reponse(dataset_response['data'], 1, "Dataset {name} already exists.".format(
                name=DatasetName
            ))
        return response

    def delete_dataset(self, DatasetName=None, DatasetId=None):
        """
        Deletes the dataset from Amorphic

        :param DatasetName: Dataset name
        :param DatasetId: Id of the dataset
        :return:
        """

        self._logger.info("In {name}, deleting dataset details for DatasetName {d_name}, and DatasetId {d_id}.".format(
            name=__name__, d_name=DatasetName, d_id=DatasetId
        ))

        _path = 'dataset_details'

        if not (DatasetId or DatasetName):
            self._logger.error("In {name}, Either DatasetName or DatasetId must be passed.".format(name=__name__))
            raise Exception('Either DatasetName or DatasetId must be passed.')

        if not DatasetId:
            dataset_response = self.get_dataset(DatasetName)
            if dataset_response['exitcode'] == 0:
                DatasetId = dataset_response['data']['DatasetId']

        if DatasetId:
            dataset_deletion_response = self.api_wrapper.make_request(_path, method='delete', fields=DatasetId,
                                                                      headers=None, verify=True)
            response = generate_json_reponse(dataset_deletion_response)
        else:
            response = dataset_response
        return response

    def update_dataset(self, DatasetName, MalwareDetectionOptions=None,
                       Keywords=None, DatasetDescription=None,
                       IsDataProfilingEnabled=None, IsDataValidationEnabled=None,
                       DataClassification=None, **kwargs):

        """
        Updates the dataset in Amorphic, returns dataset details if already exists

        :param DatasetName: Dataset name
        :param MalwareDetectionOptions: Malware detection in dict format,
            key must be from ['ScanForMalware', 'AllowUnscannableFiles'] and value can be True or False
        :param Keywords: Keywords for the dataset
        :param DatasetDescription: Description of the dataset
        :param IsDataProfilingEnabled: if want to enable data profiling, default: false
        :param IsDataValidationEnabled: Validate schema for each file for s3athena type dataset. Default: false
        :param DataClassification: data classification for the dataset
        :param kwargs:
        :return:
        """

        self._logger.info("In {name}, updating dataset details for DatasetName {d_name}.".format(
            name=__name__, d_name=DatasetName
        ))

        dataset_details_response = self.get_dataset(DatasetName=DatasetName)
        _path = 'update_dataset'
        if dataset_details_response['exitcode'] == 0:
            dataset_id = dataset_details_response['data']['DatasetId']
            arguments = locals()

            # Update arguments with existing values if empty and validate
            for key, value in arguments.items():
                if key in dataset_details_response['data'].keys() and not value:
                    arguments[key] = dataset_details_response['data'][key]
                # Python 2: Convert unicode to string
                if key == 'DatasetDescription':
                    arguments[key] = str(arguments[key])
                if key in self.dataset_param_validation_functions.keys():
                    if not self.dataset_param_validation_functions[key](arguments[key]):
                        raise Exception("Failed to validate value for key: {key} with value: {value}".
                                        format(key=key,
                                               value=arguments[key]))

            malware_detection = self._validate_malware_detection(arguments['MalwareDetectionOptions'])

            payload = {
                'MalwareDetectionOptions': malware_detection,
                'Keywords': arguments['Keywords'] if arguments['Keywords'] else ["CreatedBy:Amorphicutils"],
                'DatasetDescription': arguments['DatasetDescription'],
                'IsDataProfilingEnabled': arguments['IsDataProfilingEnabled']
            }

            if arguments['IsDataValidationEnabled']:
                payload['IsDataValidationEnabled'] = arguments['IsDataValidationEnabled']

            if arguments['DataClassification']:
                payload['DataClassification'] = arguments['DataClassification']
            else:
                payload['DataClassification'] = []

            #if arguments['kwargs']:
            #    self._logger.warning("Following arguments {args} are not used in update function "
            #                         "and thus not used under payload.".format(args=arguments['kwargs']))

            # payload, schema_payload = self._get_validated_dataset_payload(arguments)
            # payload.update(schema_payload)
            update_variables = ['Keywords', 'DataClassification', 'DatasetDescription',
                                'IsDataProfilingEnabled', 'MalwareDetectionOptions', 'IsDataValidationEnabled']

            update_payload = {key: value for key, value in payload.items() if key in update_variables}

            # Add the extra kwargs to payload
            update_payload.update(**kwargs)

            headers = {'Content-Type': 'text/plain'}
            update_dataset_response = self.api_wrapper.make_request(_path,
                                                                    fields=dataset_id,
                                                                    method='put',
                                                                    headers=headers,
                                                                    data=json.dumps(update_payload))
            response = generate_json_reponse(update_dataset_response)
        else:
            response = dataset_details_response
        return response

    def search_dataset(self, DatasetName, datasets_list=None):
        """
        Search the dataset by name

        :param DatasetName: Dataset name
        :param datasets_list:
        :return:
        """

        self._logger.info("In {name}, searching dataset details for DatasetName {d_name}.".format(
            name=__name__, d_name=DatasetName
        ))

        _path = "search_dataset"
        offset = 1
        next_available = "yes"
        datasets_list = [] if not datasets_list else datasets_list

        while next_available == "yes":
            search_response = self.api_wrapper.make_request(_path, fields=DatasetName, method='get',
                                                            headers=None, data=None,
                                                            verify=True, offset=offset)
            if search_response.status_code == 200:
                dict_response = text_to_dict(search_response.text)
                next_available = dict_response.get("next_available")
                offset = offset + dict_response["count"]
                if dict_response.get("datasets"):
                    datasets_list = datasets_list + dict_response.get("datasets")
            else:
                response = generate_json_reponse(search_response)
                return response
        if datasets_list:
            dict_response["datasets"] = datasets_list
            response = generate_json_reponse(dict_response, exitcode=0, message="Generated list of all datasets.")
        else:
            response = generate_json_reponse(None, exitcode=1, message="No dataset found.")
        return response

    def get_dataset(self, DatasetName=None, DatasetId=None):
        """
        Get the dataset details based on name or dataset id

        :param DatasetName: Dataset name
        :param DatasetId: Dataset Id
        :return:
        """

        self._logger.info("In {name}, getting dataset details for DatasetName {d_name}, and DatasetId {d_id}.".format(
            name=__name__, d_name=DatasetName, d_id=DatasetId
        ))

        if not (DatasetId or DatasetName):
            self._logger.error("In {name}, Either DatasetName or DatasetId must be passed.".format(name=__name__))
            raise Exception('Either DatasetName or DatasetId must be passed.')

        if DatasetId:
            _path = "dataset_details"
            dataset_response = self.api_wrapper.make_request(_path, fields=DatasetId, method='get',
                                                             headers=None, data=None, verify=True)
            response = generate_json_reponse(dataset_response)
        else:
            resource_id_response = self.get_resource_id("datasets", resource_name=DatasetName)
            if resource_id_response['exitcode'] == 0:
                dataset_id = resource_id_response['data']['ResourceId']
                response = self.get_dataset(DatasetId=dataset_id)
            else:
                response = resource_id_response
                # To be removed in future
                search_response_json = self.search_dataset(DatasetName)
                if search_response_json['exitcode'] == 0:
                    if search_response_json["data"]["total_count"] > 0:
                        for item in search_response_json["data"]["datasets"]:
                            if item["DatasetName"] == DatasetName:
                                response = self.get_dataset(DatasetName=DatasetName, DatasetId=item["DatasetId"])
                            else:
                                response = generate_json_reponse(None,
                                                                 exitcode=1,
                                                                 message="No Dataset found of name {name}"
                                                                 .format(name=DatasetName))
                    else:
                        response = generate_json_reponse(None, exitcode=1, message="No dataset found with name {name}"
                                                         .format(name=DatasetName))
                else:
                    response = search_response_json
                    # Get all dataset and iterate to find the dataset
                    all_dataset_response = self.get_all_dataset()
                    if all_dataset_response['exitcode'] == 0:
                        all_dataset = all_dataset_response['data']['datasets']
                        for dataset in all_dataset:
                            if dataset['DatasetName'] == DatasetName:
                                response = self.get_dataset(DatasetName=DatasetName, DatasetId=dataset["DatasetId"])
                                break
                    else:
                        response = all_dataset_response
                # Removed till here
        return response

    def get_all_dataset(self, datasets_list=None):
        """
        Returns list of all the datasets owned by user

        :param datasets_list:
        :return:
        """

        self._logger.info("In {name}, getting list of all the datasets.".format(name=__name__))
        _path = "register_dataset"
        offset = 1
        next_available = "yes"
        datasets_list = [] if not datasets_list else datasets_list
        while next_available == "yes":
            dataset_response = self.api_wrapper.make_request(_path, fields=None, method='get', headers=None,
                                                             data=None, verify=True, offset=offset)
            if dataset_response.status_code == 200:
                dict_response = text_to_dict(dataset_response.text)
                next_available = dict_response.get("next_available")
                offset = offset + dict_response["count"]
                if dict_response.get("datasets"):
                    datasets_list = datasets_list + dict_response.get("datasets")
            else:
                response = generate_json_reponse(dataset_response)
                break
        if datasets_list:
            dict_response["datasets"] = datasets_list
            response = generate_json_reponse(dict_response, exitcode=0, message="Generated list of all datasets.")
        else:
            response = generate_json_reponse(None, exitcode=1, message="No datasets found.")
        return response
